﻿namespace Battleship1
{
	partial class MainScreen
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button10 = new System.Windows.Forms.Button();
			this.button11 = new System.Windows.Forms.Button();
			this.button12 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.button14 = new System.Windows.Forms.Button();
			this.button15 = new System.Windows.Forms.Button();
			this.button16 = new System.Windows.Forms.Button();
			this.button17 = new System.Windows.Forms.Button();
			this.button18 = new System.Windows.Forms.Button();
			this.button19 = new System.Windows.Forms.Button();
			this.button20 = new System.Windows.Forms.Button();
			this.button21 = new System.Windows.Forms.Button();
			this.button22 = new System.Windows.Forms.Button();
			this.button23 = new System.Windows.Forms.Button();
			this.button24 = new System.Windows.Forms.Button();
			this.button25 = new System.Windows.Forms.Button();
			this.button26 = new System.Windows.Forms.Button();
			this.button27 = new System.Windows.Forms.Button();
			this.button28 = new System.Windows.Forms.Button();
			this.button29 = new System.Windows.Forms.Button();
			this.button30 = new System.Windows.Forms.Button();
			this.button31 = new System.Windows.Forms.Button();
			this.button32 = new System.Windows.Forms.Button();
			this.button33 = new System.Windows.Forms.Button();
			this.button34 = new System.Windows.Forms.Button();
			this.button35 = new System.Windows.Forms.Button();
			this.button36 = new System.Windows.Forms.Button();
			this.button37 = new System.Windows.Forms.Button();
			this.button38 = new System.Windows.Forms.Button();
			this.button39 = new System.Windows.Forms.Button();
			this.button40 = new System.Windows.Forms.Button();
			this.button41 = new System.Windows.Forms.Button();
			this.button42 = new System.Windows.Forms.Button();
			this.button43 = new System.Windows.Forms.Button();
			this.button44 = new System.Windows.Forms.Button();
			this.button45 = new System.Windows.Forms.Button();
			this.button46 = new System.Windows.Forms.Button();
			this.button47 = new System.Windows.Forms.Button();
			this.button48 = new System.Windows.Forms.Button();
			this.button49 = new System.Windows.Forms.Button();
			this.button50 = new System.Windows.Forms.Button();
			this.button51 = new System.Windows.Forms.Button();
			this.button52 = new System.Windows.Forms.Button();
			this.button53 = new System.Windows.Forms.Button();
			this.button54 = new System.Windows.Forms.Button();
			this.button55 = new System.Windows.Forms.Button();
			this.button56 = new System.Windows.Forms.Button();
			this.button57 = new System.Windows.Forms.Button();
			this.button58 = new System.Windows.Forms.Button();
			this.button59 = new System.Windows.Forms.Button();
			this.button60 = new System.Windows.Forms.Button();
			this.button61 = new System.Windows.Forms.Button();
			this.button62 = new System.Windows.Forms.Button();
			this.button63 = new System.Windows.Forms.Button();
			this.button64 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.P1S1 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label2 = new System.Windows.Forms.Label();
			this.P1S3 = new System.Windows.Forms.Button();
			this.P1S2 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.button65 = new System.Windows.Forms.Button();
			this.button66 = new System.Windows.Forms.Button();
			this.button67 = new System.Windows.Forms.Button();
			this.button68 = new System.Windows.Forms.Button();
			this.button69 = new System.Windows.Forms.Button();
			this.button70 = new System.Windows.Forms.Button();
			this.button71 = new System.Windows.Forms.Button();
			this.button72 = new System.Windows.Forms.Button();
			this.button73 = new System.Windows.Forms.Button();
			this.button74 = new System.Windows.Forms.Button();
			this.button75 = new System.Windows.Forms.Button();
			this.button76 = new System.Windows.Forms.Button();
			this.button77 = new System.Windows.Forms.Button();
			this.button78 = new System.Windows.Forms.Button();
			this.button79 = new System.Windows.Forms.Button();
			this.button80 = new System.Windows.Forms.Button();
			this.button81 = new System.Windows.Forms.Button();
			this.button82 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.P2S1 = new System.Windows.Forms.Button();
			this.P2S3 = new System.Windows.Forms.Button();
			this.P2S2 = new System.Windows.Forms.Button();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this.button86 = new System.Windows.Forms.Button();
			this.button87 = new System.Windows.Forms.Button();
			this.button88 = new System.Windows.Forms.Button();
			this.button89 = new System.Windows.Forms.Button();
			this.button90 = new System.Windows.Forms.Button();
			this.button91 = new System.Windows.Forms.Button();
			this.button92 = new System.Windows.Forms.Button();
			this.button93 = new System.Windows.Forms.Button();
			this.button94 = new System.Windows.Forms.Button();
			this.button95 = new System.Windows.Forms.Button();
			this.button96 = new System.Windows.Forms.Button();
			this.button97 = new System.Windows.Forms.Button();
			this.button98 = new System.Windows.Forms.Button();
			this.button99 = new System.Windows.Forms.Button();
			this.button100 = new System.Windows.Forms.Button();
			this.button101 = new System.Windows.Forms.Button();
			this.button102 = new System.Windows.Forms.Button();
			this.button103 = new System.Windows.Forms.Button();
			this.button104 = new System.Windows.Forms.Button();
			this.button105 = new System.Windows.Forms.Button();
			this.button106 = new System.Windows.Forms.Button();
			this.button107 = new System.Windows.Forms.Button();
			this.button108 = new System.Windows.Forms.Button();
			this.button109 = new System.Windows.Forms.Button();
			this.button110 = new System.Windows.Forms.Button();
			this.button111 = new System.Windows.Forms.Button();
			this.button112 = new System.Windows.Forms.Button();
			this.button113 = new System.Windows.Forms.Button();
			this.button114 = new System.Windows.Forms.Button();
			this.button115 = new System.Windows.Forms.Button();
			this.button116 = new System.Windows.Forms.Button();
			this.button117 = new System.Windows.Forms.Button();
			this.button118 = new System.Windows.Forms.Button();
			this.button119 = new System.Windows.Forms.Button();
			this.button120 = new System.Windows.Forms.Button();
			this.button121 = new System.Windows.Forms.Button();
			this.button122 = new System.Windows.Forms.Button();
			this.button123 = new System.Windows.Forms.Button();
			this.button124 = new System.Windows.Forms.Button();
			this.button125 = new System.Windows.Forms.Button();
			this.button126 = new System.Windows.Forms.Button();
			this.button127 = new System.Windows.Forms.Button();
			this.button128 = new System.Windows.Forms.Button();
			this.button129 = new System.Windows.Forms.Button();
			this.button130 = new System.Windows.Forms.Button();
			this.button131 = new System.Windows.Forms.Button();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.BackColor = System.Drawing.Color.CornflowerBlue;
			this.flowLayoutPanel1.Controls.Add(this.button1);
			this.flowLayoutPanel1.Controls.Add(this.button2);
			this.flowLayoutPanel1.Controls.Add(this.button3);
			this.flowLayoutPanel1.Controls.Add(this.button4);
			this.flowLayoutPanel1.Controls.Add(this.button5);
			this.flowLayoutPanel1.Controls.Add(this.button6);
			this.flowLayoutPanel1.Controls.Add(this.button7);
			this.flowLayoutPanel1.Controls.Add(this.button8);
			this.flowLayoutPanel1.Controls.Add(this.button9);
			this.flowLayoutPanel1.Controls.Add(this.button10);
			this.flowLayoutPanel1.Controls.Add(this.button11);
			this.flowLayoutPanel1.Controls.Add(this.button12);
			this.flowLayoutPanel1.Controls.Add(this.button13);
			this.flowLayoutPanel1.Controls.Add(this.button14);
			this.flowLayoutPanel1.Controls.Add(this.button15);
			this.flowLayoutPanel1.Controls.Add(this.button16);
			this.flowLayoutPanel1.Controls.Add(this.button17);
			this.flowLayoutPanel1.Controls.Add(this.button18);
			this.flowLayoutPanel1.Controls.Add(this.button19);
			this.flowLayoutPanel1.Controls.Add(this.button20);
			this.flowLayoutPanel1.Controls.Add(this.button21);
			this.flowLayoutPanel1.Controls.Add(this.button22);
			this.flowLayoutPanel1.Controls.Add(this.button23);
			this.flowLayoutPanel1.Controls.Add(this.button24);
			this.flowLayoutPanel1.Controls.Add(this.button25);
			this.flowLayoutPanel1.Controls.Add(this.button26);
			this.flowLayoutPanel1.Controls.Add(this.button27);
			this.flowLayoutPanel1.Controls.Add(this.button28);
			this.flowLayoutPanel1.Controls.Add(this.button29);
			this.flowLayoutPanel1.Controls.Add(this.button30);
			this.flowLayoutPanel1.Controls.Add(this.button31);
			this.flowLayoutPanel1.Controls.Add(this.button32);
			this.flowLayoutPanel1.Controls.Add(this.button33);
			this.flowLayoutPanel1.Controls.Add(this.button34);
			this.flowLayoutPanel1.Controls.Add(this.button35);
			this.flowLayoutPanel1.Controls.Add(this.button36);
			this.flowLayoutPanel1.Controls.Add(this.button37);
			this.flowLayoutPanel1.Controls.Add(this.button38);
			this.flowLayoutPanel1.Controls.Add(this.button39);
			this.flowLayoutPanel1.Controls.Add(this.button40);
			this.flowLayoutPanel1.Controls.Add(this.button41);
			this.flowLayoutPanel1.Controls.Add(this.button42);
			this.flowLayoutPanel1.Controls.Add(this.button43);
			this.flowLayoutPanel1.Controls.Add(this.button44);
			this.flowLayoutPanel1.Controls.Add(this.button45);
			this.flowLayoutPanel1.Controls.Add(this.button46);
			this.flowLayoutPanel1.Controls.Add(this.button47);
			this.flowLayoutPanel1.Controls.Add(this.button48);
			this.flowLayoutPanel1.Controls.Add(this.button49);
			this.flowLayoutPanel1.Controls.Add(this.button50);
			this.flowLayoutPanel1.Controls.Add(this.button51);
			this.flowLayoutPanel1.Controls.Add(this.button52);
			this.flowLayoutPanel1.Controls.Add(this.button53);
			this.flowLayoutPanel1.Controls.Add(this.button54);
			this.flowLayoutPanel1.Controls.Add(this.button55);
			this.flowLayoutPanel1.Controls.Add(this.button56);
			this.flowLayoutPanel1.Controls.Add(this.button57);
			this.flowLayoutPanel1.Controls.Add(this.button58);
			this.flowLayoutPanel1.Controls.Add(this.button59);
			this.flowLayoutPanel1.Controls.Add(this.button60);
			this.flowLayoutPanel1.Controls.Add(this.button61);
			this.flowLayoutPanel1.Controls.Add(this.button62);
			this.flowLayoutPanel1.Controls.Add(this.button63);
			this.flowLayoutPanel1.Controls.Add(this.button64);
			this.flowLayoutPanel1.Location = new System.Drawing.Point(36, 139);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(496, 455);
			this.flowLayoutPanel1.TabIndex = 0;
			// 
			// button1
			// 
			this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button1.Location = new System.Drawing.Point(4, 4);
			this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(53, 49);
			this.button1.TabIndex = 0;
			this.button1.Text = "A1";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button2.Location = new System.Drawing.Point(65, 4);
			this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(53, 49);
			this.button2.TabIndex = 1;
			this.button2.Text = "B1";
			this.button2.UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button3.Location = new System.Drawing.Point(126, 4);
			this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(53, 49);
			this.button3.TabIndex = 2;
			this.button3.Text = "C1";
			this.button3.UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button4.Location = new System.Drawing.Point(187, 4);
			this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(53, 49);
			this.button4.TabIndex = 3;
			this.button4.Text = "D1";
			this.button4.UseVisualStyleBackColor = true;
			// 
			// button5
			// 
			this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button5.Location = new System.Drawing.Point(248, 4);
			this.button5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(53, 49);
			this.button5.TabIndex = 4;
			this.button5.Text = "E1";
			this.button5.UseVisualStyleBackColor = true;
			// 
			// button6
			// 
			this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button6.Location = new System.Drawing.Point(309, 4);
			this.button6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(53, 49);
			this.button6.TabIndex = 5;
			this.button6.Text = "F1";
			this.button6.UseVisualStyleBackColor = true;
			// 
			// button7
			// 
			this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button7.Location = new System.Drawing.Point(370, 4);
			this.button7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(53, 49);
			this.button7.TabIndex = 6;
			this.button7.Text = "G1";
			this.button7.UseVisualStyleBackColor = true;
			// 
			// button8
			// 
			this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button8.Location = new System.Drawing.Point(431, 4);
			this.button8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(53, 49);
			this.button8.TabIndex = 7;
			this.button8.Text = "H1";
			this.button8.UseVisualStyleBackColor = true;
			// 
			// button9
			// 
			this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button9.Location = new System.Drawing.Point(4, 61);
			this.button9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(53, 49);
			this.button9.TabIndex = 8;
			this.button9.Text = "A2";
			this.button9.UseVisualStyleBackColor = true;
			// 
			// button10
			// 
			this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button10.Location = new System.Drawing.Point(65, 61);
			this.button10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(53, 49);
			this.button10.TabIndex = 9;
			this.button10.Text = "B2";
			this.button10.UseVisualStyleBackColor = true;
			// 
			// button11
			// 
			this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button11.Location = new System.Drawing.Point(126, 61);
			this.button11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(53, 49);
			this.button11.TabIndex = 10;
			this.button11.Text = "C2";
			this.button11.UseVisualStyleBackColor = true;
			// 
			// button12
			// 
			this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button12.Location = new System.Drawing.Point(187, 61);
			this.button12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(53, 49);
			this.button12.TabIndex = 11;
			this.button12.Text = "D2";
			this.button12.UseVisualStyleBackColor = true;
			// 
			// button13
			// 
			this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button13.Location = new System.Drawing.Point(248, 61);
			this.button13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(53, 49);
			this.button13.TabIndex = 12;
			this.button13.Text = "E2";
			this.button13.UseVisualStyleBackColor = true;
			// 
			// button14
			// 
			this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button14.Location = new System.Drawing.Point(309, 61);
			this.button14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button14.Name = "button14";
			this.button14.Size = new System.Drawing.Size(53, 49);
			this.button14.TabIndex = 13;
			this.button14.Text = "F2";
			this.button14.UseVisualStyleBackColor = true;
			// 
			// button15
			// 
			this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button15.Location = new System.Drawing.Point(370, 61);
			this.button15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button15.Name = "button15";
			this.button15.Size = new System.Drawing.Size(53, 49);
			this.button15.TabIndex = 14;
			this.button15.Text = "G2";
			this.button15.UseVisualStyleBackColor = true;
			// 
			// button16
			// 
			this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button16.Location = new System.Drawing.Point(431, 61);
			this.button16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button16.Name = "button16";
			this.button16.Size = new System.Drawing.Size(53, 49);
			this.button16.TabIndex = 15;
			this.button16.Text = "H2";
			this.button16.UseVisualStyleBackColor = true;
			// 
			// button17
			// 
			this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button17.Location = new System.Drawing.Point(4, 118);
			this.button17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button17.Name = "button17";
			this.button17.Size = new System.Drawing.Size(53, 49);
			this.button17.TabIndex = 16;
			this.button17.Text = "A3";
			this.button17.UseVisualStyleBackColor = true;
			// 
			// button18
			// 
			this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button18.Location = new System.Drawing.Point(65, 118);
			this.button18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button18.Name = "button18";
			this.button18.Size = new System.Drawing.Size(53, 49);
			this.button18.TabIndex = 17;
			this.button18.Text = "B3";
			this.button18.UseVisualStyleBackColor = true;
			// 
			// button19
			// 
			this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button19.Location = new System.Drawing.Point(126, 118);
			this.button19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button19.Name = "button19";
			this.button19.Size = new System.Drawing.Size(53, 49);
			this.button19.TabIndex = 18;
			this.button19.Text = "C3";
			this.button19.UseVisualStyleBackColor = true;
			// 
			// button20
			// 
			this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button20.Location = new System.Drawing.Point(187, 118);
			this.button20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button20.Name = "button20";
			this.button20.Size = new System.Drawing.Size(53, 49);
			this.button20.TabIndex = 19;
			this.button20.Text = "D3";
			this.button20.UseVisualStyleBackColor = true;
			// 
			// button21
			// 
			this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button21.Location = new System.Drawing.Point(248, 118);
			this.button21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button21.Name = "button21";
			this.button21.Size = new System.Drawing.Size(53, 49);
			this.button21.TabIndex = 20;
			this.button21.Text = "E3";
			this.button21.UseVisualStyleBackColor = true;
			// 
			// button22
			// 
			this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button22.Location = new System.Drawing.Point(309, 118);
			this.button22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button22.Name = "button22";
			this.button22.Size = new System.Drawing.Size(53, 49);
			this.button22.TabIndex = 21;
			this.button22.Text = "F3";
			this.button22.UseVisualStyleBackColor = true;
			// 
			// button23
			// 
			this.button23.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button23.Location = new System.Drawing.Point(370, 118);
			this.button23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button23.Name = "button23";
			this.button23.Size = new System.Drawing.Size(53, 49);
			this.button23.TabIndex = 22;
			this.button23.Text = "G3";
			this.button23.UseVisualStyleBackColor = true;
			// 
			// button24
			// 
			this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button24.Location = new System.Drawing.Point(431, 118);
			this.button24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button24.Name = "button24";
			this.button24.Size = new System.Drawing.Size(53, 49);
			this.button24.TabIndex = 23;
			this.button24.Text = "H3";
			this.button24.UseVisualStyleBackColor = true;
			// 
			// button25
			// 
			this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button25.Location = new System.Drawing.Point(4, 175);
			this.button25.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button25.Name = "button25";
			this.button25.Size = new System.Drawing.Size(53, 49);
			this.button25.TabIndex = 24;
			this.button25.Text = "A4";
			this.button25.UseVisualStyleBackColor = true;
			// 
			// button26
			// 
			this.button26.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button26.Location = new System.Drawing.Point(65, 175);
			this.button26.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button26.Name = "button26";
			this.button26.Size = new System.Drawing.Size(53, 49);
			this.button26.TabIndex = 25;
			this.button26.Text = "B4";
			this.button26.UseVisualStyleBackColor = true;
			// 
			// button27
			// 
			this.button27.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button27.Location = new System.Drawing.Point(126, 175);
			this.button27.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button27.Name = "button27";
			this.button27.Size = new System.Drawing.Size(53, 49);
			this.button27.TabIndex = 26;
			this.button27.Text = "C4";
			this.button27.UseVisualStyleBackColor = true;
			// 
			// button28
			// 
			this.button28.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button28.Location = new System.Drawing.Point(187, 175);
			this.button28.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button28.Name = "button28";
			this.button28.Size = new System.Drawing.Size(53, 49);
			this.button28.TabIndex = 27;
			this.button28.Text = "D4";
			this.button28.UseVisualStyleBackColor = true;
			// 
			// button29
			// 
			this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button29.Location = new System.Drawing.Point(248, 175);
			this.button29.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button29.Name = "button29";
			this.button29.Size = new System.Drawing.Size(53, 49);
			this.button29.TabIndex = 28;
			this.button29.Text = "E4";
			this.button29.UseVisualStyleBackColor = true;
			// 
			// button30
			// 
			this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button30.Location = new System.Drawing.Point(309, 175);
			this.button30.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button30.Name = "button30";
			this.button30.Size = new System.Drawing.Size(53, 49);
			this.button30.TabIndex = 29;
			this.button30.Text = "F4";
			this.button30.UseVisualStyleBackColor = true;
			// 
			// button31
			// 
			this.button31.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button31.Location = new System.Drawing.Point(370, 175);
			this.button31.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button31.Name = "button31";
			this.button31.Size = new System.Drawing.Size(53, 49);
			this.button31.TabIndex = 30;
			this.button31.Text = "G4";
			this.button31.UseVisualStyleBackColor = true;
			// 
			// button32
			// 
			this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button32.Location = new System.Drawing.Point(431, 175);
			this.button32.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button32.Name = "button32";
			this.button32.Size = new System.Drawing.Size(53, 49);
			this.button32.TabIndex = 31;
			this.button32.Text = "H4";
			this.button32.UseVisualStyleBackColor = true;
			// 
			// button33
			// 
			this.button33.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button33.Location = new System.Drawing.Point(4, 232);
			this.button33.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button33.Name = "button33";
			this.button33.Size = new System.Drawing.Size(53, 49);
			this.button33.TabIndex = 32;
			this.button33.Text = "A5";
			this.button33.UseVisualStyleBackColor = true;
			// 
			// button34
			// 
			this.button34.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button34.Location = new System.Drawing.Point(65, 232);
			this.button34.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button34.Name = "button34";
			this.button34.Size = new System.Drawing.Size(53, 49);
			this.button34.TabIndex = 33;
			this.button34.Text = "B5";
			this.button34.UseVisualStyleBackColor = true;
			// 
			// button35
			// 
			this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button35.Location = new System.Drawing.Point(126, 232);
			this.button35.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button35.Name = "button35";
			this.button35.Size = new System.Drawing.Size(53, 49);
			this.button35.TabIndex = 34;
			this.button35.Text = "C5";
			this.button35.UseVisualStyleBackColor = true;
			// 
			// button36
			// 
			this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button36.Location = new System.Drawing.Point(187, 232);
			this.button36.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button36.Name = "button36";
			this.button36.Size = new System.Drawing.Size(53, 49);
			this.button36.TabIndex = 35;
			this.button36.Text = "D5";
			this.button36.UseVisualStyleBackColor = true;
			// 
			// button37
			// 
			this.button37.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button37.Location = new System.Drawing.Point(248, 232);
			this.button37.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button37.Name = "button37";
			this.button37.Size = new System.Drawing.Size(53, 49);
			this.button37.TabIndex = 36;
			this.button37.Text = "E5";
			this.button37.UseVisualStyleBackColor = true;
			// 
			// button38
			// 
			this.button38.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button38.Location = new System.Drawing.Point(309, 232);
			this.button38.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button38.Name = "button38";
			this.button38.Size = new System.Drawing.Size(53, 49);
			this.button38.TabIndex = 37;
			this.button38.Text = "F5";
			this.button38.UseVisualStyleBackColor = true;
			// 
			// button39
			// 
			this.button39.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button39.Location = new System.Drawing.Point(370, 232);
			this.button39.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button39.Name = "button39";
			this.button39.Size = new System.Drawing.Size(53, 49);
			this.button39.TabIndex = 38;
			this.button39.Text = "G5";
			this.button39.UseVisualStyleBackColor = true;
			// 
			// button40
			// 
			this.button40.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button40.Location = new System.Drawing.Point(431, 232);
			this.button40.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button40.Name = "button40";
			this.button40.Size = new System.Drawing.Size(53, 49);
			this.button40.TabIndex = 39;
			this.button40.Text = "H5";
			this.button40.UseVisualStyleBackColor = true;
			// 
			// button41
			// 
			this.button41.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button41.Location = new System.Drawing.Point(4, 289);
			this.button41.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button41.Name = "button41";
			this.button41.Size = new System.Drawing.Size(53, 49);
			this.button41.TabIndex = 40;
			this.button41.Text = "A6";
			this.button41.UseVisualStyleBackColor = true;
			// 
			// button42
			// 
			this.button42.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button42.Location = new System.Drawing.Point(65, 289);
			this.button42.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button42.Name = "button42";
			this.button42.Size = new System.Drawing.Size(53, 49);
			this.button42.TabIndex = 41;
			this.button42.Text = "B6";
			this.button42.UseVisualStyleBackColor = true;
			// 
			// button43
			// 
			this.button43.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button43.Location = new System.Drawing.Point(126, 289);
			this.button43.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button43.Name = "button43";
			this.button43.Size = new System.Drawing.Size(53, 49);
			this.button43.TabIndex = 42;
			this.button43.Text = "C6";
			this.button43.UseVisualStyleBackColor = true;
			// 
			// button44
			// 
			this.button44.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button44.Location = new System.Drawing.Point(187, 289);
			this.button44.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button44.Name = "button44";
			this.button44.Size = new System.Drawing.Size(53, 49);
			this.button44.TabIndex = 43;
			this.button44.Text = "D6";
			this.button44.UseVisualStyleBackColor = true;
			// 
			// button45
			// 
			this.button45.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button45.Location = new System.Drawing.Point(248, 289);
			this.button45.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button45.Name = "button45";
			this.button45.Size = new System.Drawing.Size(53, 49);
			this.button45.TabIndex = 44;
			this.button45.Text = "E6";
			this.button45.UseVisualStyleBackColor = true;
			// 
			// button46
			// 
			this.button46.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button46.Location = new System.Drawing.Point(309, 289);
			this.button46.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button46.Name = "button46";
			this.button46.Size = new System.Drawing.Size(53, 49);
			this.button46.TabIndex = 45;
			this.button46.Text = "F6";
			this.button46.UseVisualStyleBackColor = true;
			// 
			// button47
			// 
			this.button47.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button47.Location = new System.Drawing.Point(370, 289);
			this.button47.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button47.Name = "button47";
			this.button47.Size = new System.Drawing.Size(53, 49);
			this.button47.TabIndex = 46;
			this.button47.Text = "G6";
			this.button47.UseVisualStyleBackColor = true;
			// 
			// button48
			// 
			this.button48.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button48.Location = new System.Drawing.Point(431, 289);
			this.button48.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button48.Name = "button48";
			this.button48.Size = new System.Drawing.Size(53, 49);
			this.button48.TabIndex = 47;
			this.button48.Text = "H6";
			this.button48.UseVisualStyleBackColor = true;
			// 
			// button49
			// 
			this.button49.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button49.Location = new System.Drawing.Point(4, 346);
			this.button49.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button49.Name = "button49";
			this.button49.Size = new System.Drawing.Size(53, 49);
			this.button49.TabIndex = 48;
			this.button49.Text = "A7";
			this.button49.UseVisualStyleBackColor = true;
			// 
			// button50
			// 
			this.button50.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button50.Location = new System.Drawing.Point(65, 346);
			this.button50.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button50.Name = "button50";
			this.button50.Size = new System.Drawing.Size(53, 49);
			this.button50.TabIndex = 49;
			this.button50.Text = "B7";
			this.button50.UseVisualStyleBackColor = true;
			// 
			// button51
			// 
			this.button51.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button51.Location = new System.Drawing.Point(126, 346);
			this.button51.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button51.Name = "button51";
			this.button51.Size = new System.Drawing.Size(53, 49);
			this.button51.TabIndex = 50;
			this.button51.Text = "C7";
			this.button51.UseVisualStyleBackColor = true;
			// 
			// button52
			// 
			this.button52.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button52.Location = new System.Drawing.Point(187, 346);
			this.button52.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button52.Name = "button52";
			this.button52.Size = new System.Drawing.Size(53, 49);
			this.button52.TabIndex = 51;
			this.button52.Text = "D7";
			this.button52.UseVisualStyleBackColor = true;
			// 
			// button53
			// 
			this.button53.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button53.Location = new System.Drawing.Point(248, 346);
			this.button53.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button53.Name = "button53";
			this.button53.Size = new System.Drawing.Size(53, 49);
			this.button53.TabIndex = 52;
			this.button53.Text = "E7";
			this.button53.UseVisualStyleBackColor = true;
			// 
			// button54
			// 
			this.button54.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button54.Location = new System.Drawing.Point(309, 346);
			this.button54.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button54.Name = "button54";
			this.button54.Size = new System.Drawing.Size(53, 49);
			this.button54.TabIndex = 53;
			this.button54.Text = "F7";
			this.button54.UseVisualStyleBackColor = true;
			// 
			// button55
			// 
			this.button55.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button55.Location = new System.Drawing.Point(370, 346);
			this.button55.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button55.Name = "button55";
			this.button55.Size = new System.Drawing.Size(53, 49);
			this.button55.TabIndex = 54;
			this.button55.Text = "G7";
			this.button55.UseVisualStyleBackColor = true;
			// 
			// button56
			// 
			this.button56.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button56.Location = new System.Drawing.Point(431, 346);
			this.button56.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button56.Name = "button56";
			this.button56.Size = new System.Drawing.Size(53, 49);
			this.button56.TabIndex = 55;
			this.button56.Text = "H7";
			this.button56.UseVisualStyleBackColor = true;
			// 
			// button57
			// 
			this.button57.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button57.Location = new System.Drawing.Point(4, 403);
			this.button57.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button57.Name = "button57";
			this.button57.Size = new System.Drawing.Size(53, 49);
			this.button57.TabIndex = 56;
			this.button57.Text = "A8";
			this.button57.UseVisualStyleBackColor = true;
			// 
			// button58
			// 
			this.button58.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button58.Location = new System.Drawing.Point(65, 403);
			this.button58.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button58.Name = "button58";
			this.button58.Size = new System.Drawing.Size(53, 49);
			this.button58.TabIndex = 57;
			this.button58.Text = "B8";
			this.button58.UseVisualStyleBackColor = true;
			// 
			// button59
			// 
			this.button59.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button59.Location = new System.Drawing.Point(126, 403);
			this.button59.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button59.Name = "button59";
			this.button59.Size = new System.Drawing.Size(53, 49);
			this.button59.TabIndex = 58;
			this.button59.Text = "C8";
			this.button59.UseVisualStyleBackColor = true;
			// 
			// button60
			// 
			this.button60.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button60.Location = new System.Drawing.Point(187, 403);
			this.button60.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button60.Name = "button60";
			this.button60.Size = new System.Drawing.Size(53, 49);
			this.button60.TabIndex = 59;
			this.button60.Text = "D8";
			this.button60.UseVisualStyleBackColor = true;
			// 
			// button61
			// 
			this.button61.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button61.Location = new System.Drawing.Point(248, 403);
			this.button61.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button61.Name = "button61";
			this.button61.Size = new System.Drawing.Size(53, 49);
			this.button61.TabIndex = 60;
			this.button61.Text = "E8";
			this.button61.UseVisualStyleBackColor = true;
			// 
			// button62
			// 
			this.button62.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button62.Location = new System.Drawing.Point(309, 403);
			this.button62.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button62.Name = "button62";
			this.button62.Size = new System.Drawing.Size(53, 49);
			this.button62.TabIndex = 61;
			this.button62.Text = "F8";
			this.button62.UseVisualStyleBackColor = true;
			// 
			// button63
			// 
			this.button63.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button63.Location = new System.Drawing.Point(370, 403);
			this.button63.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button63.Name = "button63";
			this.button63.Size = new System.Drawing.Size(53, 49);
			this.button63.TabIndex = 62;
			this.button63.Text = "G8";
			this.button63.UseVisualStyleBackColor = true;
			// 
			// button64
			// 
			this.button64.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button64.Location = new System.Drawing.Point(431, 403);
			this.button64.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button64.Name = "button64";
			this.button64.Size = new System.Drawing.Size(53, 49);
			this.button64.TabIndex = 63;
			this.button64.Text = "H8";
			this.button64.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.label1.BackColor = System.Drawing.SystemColors.Info;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(107, 21);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(1211, 24);
			this.label1.TabIndex = 0;
			this.label1.Text = "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Battleship >>>>>>>>>>>>>>>>>>>" +
    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// P1S1
			// 
			this.P1S1.BackColor = System.Drawing.Color.CornflowerBlue;
			this.P1S1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.P1S1.Enabled = false;
			this.P1S1.FlatAppearance.BorderSize = 0;
			this.P1S1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.P1S1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.P1S1.ForeColor = System.Drawing.SystemColors.Window;
			this.P1S1.Location = new System.Drawing.Point(291, 17);
			this.P1S1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.P1S1.Name = "P1S1";
			this.P1S1.Size = new System.Drawing.Size(53, 49);
			this.P1S1.TabIndex = 64;
			this.P1S1.Text = "_";
			this.P1S1.UseVisualStyleBackColor = false;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.P1S1);
			this.groupBox1.Controls.Add(this.P1S3);
			this.groupBox1.Controls.Add(this.P1S2);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(16, 69);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupBox1.Size = new System.Drawing.Size(541, 540);
			this.groupBox1.TabIndex = 67;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Player 1";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(81, 30);
			this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(191, 24);
			this.label2.TabIndex = 70;
			this.label2.Text = "Chosen ship position:";
			// 
			// P1S3
			// 
			this.P1S3.BackColor = System.Drawing.Color.CornflowerBlue;
			this.P1S3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.P1S3.Enabled = false;
			this.P1S3.FlatAppearance.BorderSize = 0;
			this.P1S3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.P1S3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.P1S3.ForeColor = System.Drawing.SystemColors.Window;
			this.P1S3.Location = new System.Drawing.Point(413, 17);
			this.P1S3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.P1S3.Name = "P1S3";
			this.P1S3.Size = new System.Drawing.Size(53, 49);
			this.P1S3.TabIndex = 69;
			this.P1S3.Text = "_";
			this.P1S3.UseVisualStyleBackColor = false;
			// 
			// P1S2
			// 
			this.P1S2.BackColor = System.Drawing.Color.CornflowerBlue;
			this.P1S2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.P1S2.Enabled = false;
			this.P1S2.FlatAppearance.BorderSize = 0;
			this.P1S2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.P1S2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.P1S2.ForeColor = System.Drawing.SystemColors.Window;
			this.P1S2.Location = new System.Drawing.Point(352, 17);
			this.P1S2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.P1S2.Name = "P1S2";
			this.P1S2.Size = new System.Drawing.Size(53, 49);
			this.P1S2.TabIndex = 68;
			this.P1S2.Text = "_";
			this.P1S2.UseVisualStyleBackColor = false;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(81, 30);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(191, 24);
			this.label3.TabIndex = 70;
			this.label3.Text = "Chosen ship position:";
			// 
			// button65
			// 
			this.button65.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button65.Location = new System.Drawing.Point(4, 4);
			this.button65.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button65.Name = "button65";
			this.button65.Size = new System.Drawing.Size(53, 49);
			this.button65.TabIndex = 0;
			this.button65.Text = "A1";
			this.button65.UseVisualStyleBackColor = true;
			// 
			// button66
			// 
			this.button66.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button66.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button66.Location = new System.Drawing.Point(65, 4);
			this.button66.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button66.Name = "button66";
			this.button66.Size = new System.Drawing.Size(53, 49);
			this.button66.TabIndex = 1;
			this.button66.Text = "B1";
			this.button66.UseVisualStyleBackColor = true;
			// 
			// button67
			// 
			this.button67.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button67.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button67.Location = new System.Drawing.Point(126, 4);
			this.button67.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button67.Name = "button67";
			this.button67.Size = new System.Drawing.Size(53, 49);
			this.button67.TabIndex = 2;
			this.button67.Text = "C1";
			this.button67.UseVisualStyleBackColor = true;
			// 
			// button68
			// 
			this.button68.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button68.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button68.Location = new System.Drawing.Point(187, 4);
			this.button68.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button68.Name = "button68";
			this.button68.Size = new System.Drawing.Size(53, 49);
			this.button68.TabIndex = 3;
			this.button68.Text = "D1";
			this.button68.UseVisualStyleBackColor = true;
			// 
			// button69
			// 
			this.button69.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button69.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button69.Location = new System.Drawing.Point(248, 4);
			this.button69.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button69.Name = "button69";
			this.button69.Size = new System.Drawing.Size(53, 49);
			this.button69.TabIndex = 4;
			this.button69.Text = "E1";
			this.button69.UseVisualStyleBackColor = true;
			// 
			// button70
			// 
			this.button70.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button70.Location = new System.Drawing.Point(309, 4);
			this.button70.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button70.Name = "button70";
			this.button70.Size = new System.Drawing.Size(53, 49);
			this.button70.TabIndex = 5;
			this.button70.Text = "F1";
			this.button70.UseVisualStyleBackColor = true;
			// 
			// button71
			// 
			this.button71.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button71.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button71.Location = new System.Drawing.Point(370, 4);
			this.button71.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button71.Name = "button71";
			this.button71.Size = new System.Drawing.Size(53, 49);
			this.button71.TabIndex = 6;
			this.button71.Text = "G1";
			this.button71.UseVisualStyleBackColor = true;
			// 
			// button72
			// 
			this.button72.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button72.Location = new System.Drawing.Point(431, 4);
			this.button72.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button72.Name = "button72";
			this.button72.Size = new System.Drawing.Size(53, 49);
			this.button72.TabIndex = 7;
			this.button72.Text = "H1";
			this.button72.UseVisualStyleBackColor = true;
			// 
			// button73
			// 
			this.button73.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button73.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button73.Location = new System.Drawing.Point(4, 61);
			this.button73.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button73.Name = "button73";
			this.button73.Size = new System.Drawing.Size(53, 49);
			this.button73.TabIndex = 8;
			this.button73.Text = "A2";
			this.button73.UseVisualStyleBackColor = true;
			// 
			// button74
			// 
			this.button74.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button74.Location = new System.Drawing.Point(65, 61);
			this.button74.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button74.Name = "button74";
			this.button74.Size = new System.Drawing.Size(53, 49);
			this.button74.TabIndex = 9;
			this.button74.Text = "B2";
			this.button74.UseVisualStyleBackColor = true;
			// 
			// button75
			// 
			this.button75.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button75.Location = new System.Drawing.Point(126, 61);
			this.button75.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button75.Name = "button75";
			this.button75.Size = new System.Drawing.Size(53, 49);
			this.button75.TabIndex = 10;
			this.button75.Text = "C2";
			this.button75.UseVisualStyleBackColor = true;
			// 
			// button76
			// 
			this.button76.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button76.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button76.Location = new System.Drawing.Point(187, 61);
			this.button76.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button76.Name = "button76";
			this.button76.Size = new System.Drawing.Size(53, 49);
			this.button76.TabIndex = 11;
			this.button76.Text = "D2";
			this.button76.UseVisualStyleBackColor = true;
			// 
			// button77
			// 
			this.button77.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button77.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button77.Location = new System.Drawing.Point(248, 61);
			this.button77.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button77.Name = "button77";
			this.button77.Size = new System.Drawing.Size(53, 49);
			this.button77.TabIndex = 12;
			this.button77.Text = "E2";
			this.button77.UseVisualStyleBackColor = true;
			// 
			// button78
			// 
			this.button78.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button78.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button78.Location = new System.Drawing.Point(309, 61);
			this.button78.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button78.Name = "button78";
			this.button78.Size = new System.Drawing.Size(53, 49);
			this.button78.TabIndex = 13;
			this.button78.Text = "F2";
			this.button78.UseVisualStyleBackColor = true;
			// 
			// button79
			// 
			this.button79.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button79.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button79.Location = new System.Drawing.Point(370, 61);
			this.button79.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button79.Name = "button79";
			this.button79.Size = new System.Drawing.Size(53, 49);
			this.button79.TabIndex = 14;
			this.button79.Text = "G2";
			this.button79.UseVisualStyleBackColor = true;
			// 
			// button80
			// 
			this.button80.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button80.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button80.Location = new System.Drawing.Point(431, 61);
			this.button80.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button80.Name = "button80";
			this.button80.Size = new System.Drawing.Size(53, 49);
			this.button80.TabIndex = 15;
			this.button80.Text = "H2";
			this.button80.UseVisualStyleBackColor = true;
			// 
			// button81
			// 
			this.button81.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button81.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button81.Location = new System.Drawing.Point(4, 118);
			this.button81.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button81.Name = "button81";
			this.button81.Size = new System.Drawing.Size(53, 49);
			this.button81.TabIndex = 16;
			this.button81.Text = "A3";
			this.button81.UseVisualStyleBackColor = true;
			// 
			// button82
			// 
			this.button82.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button82.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button82.Location = new System.Drawing.Point(65, 118);
			this.button82.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button82.Name = "button82";
			this.button82.Size = new System.Drawing.Size(53, 49);
			this.button82.TabIndex = 17;
			this.button82.Text = "B3";
			this.button82.UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.P2S1);
			this.groupBox2.Controls.Add(this.P2S3);
			this.groupBox2.Controls.Add(this.P2S2);
			this.groupBox2.Controls.Add(this.flowLayoutPanel2);
			this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox2.Location = new System.Drawing.Point(852, 69);
			this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupBox2.Size = new System.Drawing.Size(541, 540);
			this.groupBox2.TabIndex = 70;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Player 2";
			// 
			// P2S1
			// 
			this.P2S1.BackColor = System.Drawing.Color.YellowGreen;
			this.P2S1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.P2S1.Enabled = false;
			this.P2S1.FlatAppearance.BorderSize = 0;
			this.P2S1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.P2S1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.P2S1.ForeColor = System.Drawing.SystemColors.Window;
			this.P2S1.Location = new System.Drawing.Point(291, 17);
			this.P2S1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.P2S1.Name = "P2S1";
			this.P2S1.Size = new System.Drawing.Size(53, 49);
			this.P2S1.TabIndex = 64;
			this.P2S1.Text = "_";
			this.P2S1.UseVisualStyleBackColor = false;
			// 
			// P2S3
			// 
			this.P2S3.BackColor = System.Drawing.Color.YellowGreen;
			this.P2S3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.P2S3.Enabled = false;
			this.P2S3.FlatAppearance.BorderSize = 0;
			this.P2S3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.P2S3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.P2S3.ForeColor = System.Drawing.SystemColors.Window;
			this.P2S3.Location = new System.Drawing.Point(413, 17);
			this.P2S3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.P2S3.Name = "P2S3";
			this.P2S3.Size = new System.Drawing.Size(53, 49);
			this.P2S3.TabIndex = 69;
			this.P2S3.Text = "_";
			this.P2S3.UseVisualStyleBackColor = false;
			// 
			// P2S2
			// 
			this.P2S2.BackColor = System.Drawing.Color.YellowGreen;
			this.P2S2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.P2S2.Enabled = false;
			this.P2S2.FlatAppearance.BorderSize = 0;
			this.P2S2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.P2S2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.P2S2.ForeColor = System.Drawing.SystemColors.Window;
			this.P2S2.Location = new System.Drawing.Point(352, 17);
			this.P2S2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.P2S2.Name = "P2S2";
			this.P2S2.Size = new System.Drawing.Size(53, 49);
			this.P2S2.TabIndex = 68;
			this.P2S2.Text = "_";
			this.P2S2.UseVisualStyleBackColor = false;
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.BackColor = System.Drawing.Color.YellowGreen;
			this.flowLayoutPanel2.Controls.Add(this.button65);
			this.flowLayoutPanel2.Controls.Add(this.button66);
			this.flowLayoutPanel2.Controls.Add(this.button67);
			this.flowLayoutPanel2.Controls.Add(this.button68);
			this.flowLayoutPanel2.Controls.Add(this.button69);
			this.flowLayoutPanel2.Controls.Add(this.button70);
			this.flowLayoutPanel2.Controls.Add(this.button71);
			this.flowLayoutPanel2.Controls.Add(this.button72);
			this.flowLayoutPanel2.Controls.Add(this.button73);
			this.flowLayoutPanel2.Controls.Add(this.button74);
			this.flowLayoutPanel2.Controls.Add(this.button75);
			this.flowLayoutPanel2.Controls.Add(this.button76);
			this.flowLayoutPanel2.Controls.Add(this.button77);
			this.flowLayoutPanel2.Controls.Add(this.button78);
			this.flowLayoutPanel2.Controls.Add(this.button79);
			this.flowLayoutPanel2.Controls.Add(this.button80);
			this.flowLayoutPanel2.Controls.Add(this.button81);
			this.flowLayoutPanel2.Controls.Add(this.button82);
			this.flowLayoutPanel2.Controls.Add(this.button86);
			this.flowLayoutPanel2.Controls.Add(this.button87);
			this.flowLayoutPanel2.Controls.Add(this.button88);
			this.flowLayoutPanel2.Controls.Add(this.button89);
			this.flowLayoutPanel2.Controls.Add(this.button90);
			this.flowLayoutPanel2.Controls.Add(this.button91);
			this.flowLayoutPanel2.Controls.Add(this.button92);
			this.flowLayoutPanel2.Controls.Add(this.button93);
			this.flowLayoutPanel2.Controls.Add(this.button94);
			this.flowLayoutPanel2.Controls.Add(this.button95);
			this.flowLayoutPanel2.Controls.Add(this.button96);
			this.flowLayoutPanel2.Controls.Add(this.button97);
			this.flowLayoutPanel2.Controls.Add(this.button98);
			this.flowLayoutPanel2.Controls.Add(this.button99);
			this.flowLayoutPanel2.Controls.Add(this.button100);
			this.flowLayoutPanel2.Controls.Add(this.button101);
			this.flowLayoutPanel2.Controls.Add(this.button102);
			this.flowLayoutPanel2.Controls.Add(this.button103);
			this.flowLayoutPanel2.Controls.Add(this.button104);
			this.flowLayoutPanel2.Controls.Add(this.button105);
			this.flowLayoutPanel2.Controls.Add(this.button106);
			this.flowLayoutPanel2.Controls.Add(this.button107);
			this.flowLayoutPanel2.Controls.Add(this.button108);
			this.flowLayoutPanel2.Controls.Add(this.button109);
			this.flowLayoutPanel2.Controls.Add(this.button110);
			this.flowLayoutPanel2.Controls.Add(this.button111);
			this.flowLayoutPanel2.Controls.Add(this.button112);
			this.flowLayoutPanel2.Controls.Add(this.button113);
			this.flowLayoutPanel2.Controls.Add(this.button114);
			this.flowLayoutPanel2.Controls.Add(this.button115);
			this.flowLayoutPanel2.Controls.Add(this.button116);
			this.flowLayoutPanel2.Controls.Add(this.button117);
			this.flowLayoutPanel2.Controls.Add(this.button118);
			this.flowLayoutPanel2.Controls.Add(this.button119);
			this.flowLayoutPanel2.Controls.Add(this.button120);
			this.flowLayoutPanel2.Controls.Add(this.button121);
			this.flowLayoutPanel2.Controls.Add(this.button122);
			this.flowLayoutPanel2.Controls.Add(this.button123);
			this.flowLayoutPanel2.Controls.Add(this.button124);
			this.flowLayoutPanel2.Controls.Add(this.button125);
			this.flowLayoutPanel2.Controls.Add(this.button126);
			this.flowLayoutPanel2.Controls.Add(this.button127);
			this.flowLayoutPanel2.Controls.Add(this.button128);
			this.flowLayoutPanel2.Controls.Add(this.button129);
			this.flowLayoutPanel2.Controls.Add(this.button130);
			this.flowLayoutPanel2.Controls.Add(this.button131);
			this.flowLayoutPanel2.Location = new System.Drawing.Point(24, 74);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(496, 455);
			this.flowLayoutPanel2.TabIndex = 68;
			// 
			// button86
			// 
			this.button86.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button86.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button86.Location = new System.Drawing.Point(126, 118);
			this.button86.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button86.Name = "button86";
			this.button86.Size = new System.Drawing.Size(53, 49);
			this.button86.TabIndex = 18;
			this.button86.Text = "C3";
			this.button86.UseVisualStyleBackColor = true;
			// 
			// button87
			// 
			this.button87.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button87.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button87.Location = new System.Drawing.Point(187, 118);
			this.button87.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button87.Name = "button87";
			this.button87.Size = new System.Drawing.Size(53, 49);
			this.button87.TabIndex = 19;
			this.button87.Text = "D3";
			this.button87.UseVisualStyleBackColor = true;
			// 
			// button88
			// 
			this.button88.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button88.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button88.Location = new System.Drawing.Point(248, 118);
			this.button88.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button88.Name = "button88";
			this.button88.Size = new System.Drawing.Size(53, 49);
			this.button88.TabIndex = 20;
			this.button88.Text = "E3";
			this.button88.UseVisualStyleBackColor = true;
			// 
			// button89
			// 
			this.button89.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button89.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button89.Location = new System.Drawing.Point(309, 118);
			this.button89.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button89.Name = "button89";
			this.button89.Size = new System.Drawing.Size(53, 49);
			this.button89.TabIndex = 21;
			this.button89.Text = "F3";
			this.button89.UseVisualStyleBackColor = true;
			// 
			// button90
			// 
			this.button90.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button90.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button90.Location = new System.Drawing.Point(370, 118);
			this.button90.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button90.Name = "button90";
			this.button90.Size = new System.Drawing.Size(53, 49);
			this.button90.TabIndex = 22;
			this.button90.Text = "G3";
			this.button90.UseVisualStyleBackColor = true;
			// 
			// button91
			// 
			this.button91.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button91.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button91.Location = new System.Drawing.Point(431, 118);
			this.button91.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button91.Name = "button91";
			this.button91.Size = new System.Drawing.Size(53, 49);
			this.button91.TabIndex = 23;
			this.button91.Text = "H3";
			this.button91.UseVisualStyleBackColor = true;
			// 
			// button92
			// 
			this.button92.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button92.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button92.Location = new System.Drawing.Point(4, 175);
			this.button92.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button92.Name = "button92";
			this.button92.Size = new System.Drawing.Size(53, 49);
			this.button92.TabIndex = 24;
			this.button92.Text = "A4";
			this.button92.UseVisualStyleBackColor = true;
			// 
			// button93
			// 
			this.button93.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button93.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button93.Location = new System.Drawing.Point(65, 175);
			this.button93.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button93.Name = "button93";
			this.button93.Size = new System.Drawing.Size(53, 49);
			this.button93.TabIndex = 25;
			this.button93.Text = "B4";
			this.button93.UseVisualStyleBackColor = true;
			// 
			// button94
			// 
			this.button94.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button94.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button94.Location = new System.Drawing.Point(126, 175);
			this.button94.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button94.Name = "button94";
			this.button94.Size = new System.Drawing.Size(53, 49);
			this.button94.TabIndex = 26;
			this.button94.Text = "C4";
			this.button94.UseVisualStyleBackColor = true;
			// 
			// button95
			// 
			this.button95.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button95.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button95.Location = new System.Drawing.Point(187, 175);
			this.button95.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button95.Name = "button95";
			this.button95.Size = new System.Drawing.Size(53, 49);
			this.button95.TabIndex = 27;
			this.button95.Text = "D4";
			this.button95.UseVisualStyleBackColor = true;
			// 
			// button96
			// 
			this.button96.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button96.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button96.Location = new System.Drawing.Point(248, 175);
			this.button96.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button96.Name = "button96";
			this.button96.Size = new System.Drawing.Size(53, 49);
			this.button96.TabIndex = 28;
			this.button96.Text = "E4";
			this.button96.UseVisualStyleBackColor = true;
			// 
			// button97
			// 
			this.button97.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button97.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button97.Location = new System.Drawing.Point(309, 175);
			this.button97.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button97.Name = "button97";
			this.button97.Size = new System.Drawing.Size(53, 49);
			this.button97.TabIndex = 29;
			this.button97.Text = "F4";
			this.button97.UseVisualStyleBackColor = true;
			// 
			// button98
			// 
			this.button98.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button98.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button98.Location = new System.Drawing.Point(370, 175);
			this.button98.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button98.Name = "button98";
			this.button98.Size = new System.Drawing.Size(53, 49);
			this.button98.TabIndex = 30;
			this.button98.Text = "G4";
			this.button98.UseVisualStyleBackColor = true;
			// 
			// button99
			// 
			this.button99.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button99.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button99.Location = new System.Drawing.Point(431, 175);
			this.button99.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button99.Name = "button99";
			this.button99.Size = new System.Drawing.Size(53, 49);
			this.button99.TabIndex = 31;
			this.button99.Text = "H4";
			this.button99.UseVisualStyleBackColor = true;
			// 
			// button100
			// 
			this.button100.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button100.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button100.Location = new System.Drawing.Point(4, 232);
			this.button100.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button100.Name = "button100";
			this.button100.Size = new System.Drawing.Size(53, 49);
			this.button100.TabIndex = 32;
			this.button100.Text = "A5";
			this.button100.UseVisualStyleBackColor = true;
			// 
			// button101
			// 
			this.button101.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button101.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button101.Location = new System.Drawing.Point(65, 232);
			this.button101.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button101.Name = "button101";
			this.button101.Size = new System.Drawing.Size(53, 49);
			this.button101.TabIndex = 33;
			this.button101.Text = "B5";
			this.button101.UseVisualStyleBackColor = true;
			// 
			// button102
			// 
			this.button102.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button102.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button102.Location = new System.Drawing.Point(126, 232);
			this.button102.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button102.Name = "button102";
			this.button102.Size = new System.Drawing.Size(53, 49);
			this.button102.TabIndex = 34;
			this.button102.Text = "C5";
			this.button102.UseVisualStyleBackColor = true;
			// 
			// button103
			// 
			this.button103.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button103.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button103.Location = new System.Drawing.Point(187, 232);
			this.button103.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button103.Name = "button103";
			this.button103.Size = new System.Drawing.Size(53, 49);
			this.button103.TabIndex = 35;
			this.button103.Text = "D5";
			this.button103.UseVisualStyleBackColor = true;
			// 
			// button104
			// 
			this.button104.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button104.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button104.Location = new System.Drawing.Point(248, 232);
			this.button104.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button104.Name = "button104";
			this.button104.Size = new System.Drawing.Size(53, 49);
			this.button104.TabIndex = 36;
			this.button104.Text = "E5";
			this.button104.UseVisualStyleBackColor = true;
			// 
			// button105
			// 
			this.button105.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button105.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button105.Location = new System.Drawing.Point(309, 232);
			this.button105.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button105.Name = "button105";
			this.button105.Size = new System.Drawing.Size(53, 49);
			this.button105.TabIndex = 37;
			this.button105.Text = "F5";
			this.button105.UseVisualStyleBackColor = true;
			// 
			// button106
			// 
			this.button106.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button106.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button106.Location = new System.Drawing.Point(370, 232);
			this.button106.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button106.Name = "button106";
			this.button106.Size = new System.Drawing.Size(53, 49);
			this.button106.TabIndex = 38;
			this.button106.Text = "G5";
			this.button106.UseVisualStyleBackColor = true;
			// 
			// button107
			// 
			this.button107.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button107.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button107.Location = new System.Drawing.Point(431, 232);
			this.button107.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button107.Name = "button107";
			this.button107.Size = new System.Drawing.Size(53, 49);
			this.button107.TabIndex = 39;
			this.button107.Text = "H5";
			this.button107.UseVisualStyleBackColor = true;
			// 
			// button108
			// 
			this.button108.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button108.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button108.Location = new System.Drawing.Point(4, 289);
			this.button108.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button108.Name = "button108";
			this.button108.Size = new System.Drawing.Size(53, 49);
			this.button108.TabIndex = 40;
			this.button108.Text = "A6";
			this.button108.UseVisualStyleBackColor = true;
			// 
			// button109
			// 
			this.button109.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button109.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button109.Location = new System.Drawing.Point(65, 289);
			this.button109.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button109.Name = "button109";
			this.button109.Size = new System.Drawing.Size(53, 49);
			this.button109.TabIndex = 41;
			this.button109.Text = "B6";
			this.button109.UseVisualStyleBackColor = true;
			// 
			// button110
			// 
			this.button110.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button110.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button110.Location = new System.Drawing.Point(126, 289);
			this.button110.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button110.Name = "button110";
			this.button110.Size = new System.Drawing.Size(53, 49);
			this.button110.TabIndex = 42;
			this.button110.Text = "C6";
			this.button110.UseVisualStyleBackColor = true;
			// 
			// button111
			// 
			this.button111.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button111.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button111.Location = new System.Drawing.Point(187, 289);
			this.button111.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button111.Name = "button111";
			this.button111.Size = new System.Drawing.Size(53, 49);
			this.button111.TabIndex = 43;
			this.button111.Text = "D6";
			this.button111.UseVisualStyleBackColor = true;
			// 
			// button112
			// 
			this.button112.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button112.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button112.Location = new System.Drawing.Point(248, 289);
			this.button112.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button112.Name = "button112";
			this.button112.Size = new System.Drawing.Size(53, 49);
			this.button112.TabIndex = 44;
			this.button112.Text = "E6";
			this.button112.UseVisualStyleBackColor = true;
			// 
			// button113
			// 
			this.button113.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button113.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button113.Location = new System.Drawing.Point(309, 289);
			this.button113.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button113.Name = "button113";
			this.button113.Size = new System.Drawing.Size(53, 49);
			this.button113.TabIndex = 45;
			this.button113.Text = "F6";
			this.button113.UseVisualStyleBackColor = true;
			// 
			// button114
			// 
			this.button114.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button114.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button114.Location = new System.Drawing.Point(370, 289);
			this.button114.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button114.Name = "button114";
			this.button114.Size = new System.Drawing.Size(53, 49);
			this.button114.TabIndex = 46;
			this.button114.Text = "G6";
			this.button114.UseVisualStyleBackColor = true;
			// 
			// button115
			// 
			this.button115.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button115.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button115.Location = new System.Drawing.Point(431, 289);
			this.button115.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button115.Name = "button115";
			this.button115.Size = new System.Drawing.Size(53, 49);
			this.button115.TabIndex = 47;
			this.button115.Text = "H6";
			this.button115.UseVisualStyleBackColor = true;
			// 
			// button116
			// 
			this.button116.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button116.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button116.Location = new System.Drawing.Point(4, 346);
			this.button116.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button116.Name = "button116";
			this.button116.Size = new System.Drawing.Size(53, 49);
			this.button116.TabIndex = 48;
			this.button116.Text = "A7";
			this.button116.UseVisualStyleBackColor = true;
			// 
			// button117
			// 
			this.button117.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button117.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button117.Location = new System.Drawing.Point(65, 346);
			this.button117.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button117.Name = "button117";
			this.button117.Size = new System.Drawing.Size(53, 49);
			this.button117.TabIndex = 49;
			this.button117.Text = "B7";
			this.button117.UseVisualStyleBackColor = true;
			// 
			// button118
			// 
			this.button118.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button118.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button118.Location = new System.Drawing.Point(126, 346);
			this.button118.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button118.Name = "button118";
			this.button118.Size = new System.Drawing.Size(53, 49);
			this.button118.TabIndex = 50;
			this.button118.Text = "C7";
			this.button118.UseVisualStyleBackColor = true;
			// 
			// button119
			// 
			this.button119.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button119.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button119.Location = new System.Drawing.Point(187, 346);
			this.button119.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button119.Name = "button119";
			this.button119.Size = new System.Drawing.Size(53, 49);
			this.button119.TabIndex = 51;
			this.button119.Text = "D7";
			this.button119.UseVisualStyleBackColor = true;
			// 
			// button120
			// 
			this.button120.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button120.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button120.Location = new System.Drawing.Point(248, 346);
			this.button120.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button120.Name = "button120";
			this.button120.Size = new System.Drawing.Size(53, 49);
			this.button120.TabIndex = 52;
			this.button120.Text = "E7";
			this.button120.UseVisualStyleBackColor = true;
			// 
			// button121
			// 
			this.button121.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button121.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button121.Location = new System.Drawing.Point(309, 346);
			this.button121.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button121.Name = "button121";
			this.button121.Size = new System.Drawing.Size(53, 49);
			this.button121.TabIndex = 53;
			this.button121.Text = "F7";
			this.button121.UseVisualStyleBackColor = true;
			// 
			// button122
			// 
			this.button122.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button122.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button122.Location = new System.Drawing.Point(370, 346);
			this.button122.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button122.Name = "button122";
			this.button122.Size = new System.Drawing.Size(53, 49);
			this.button122.TabIndex = 54;
			this.button122.Text = "G7";
			this.button122.UseVisualStyleBackColor = true;
			// 
			// button123
			// 
			this.button123.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button123.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button123.Location = new System.Drawing.Point(431, 346);
			this.button123.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button123.Name = "button123";
			this.button123.Size = new System.Drawing.Size(53, 49);
			this.button123.TabIndex = 55;
			this.button123.Text = "H7";
			this.button123.UseVisualStyleBackColor = true;
			// 
			// button124
			// 
			this.button124.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button124.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button124.Location = new System.Drawing.Point(4, 403);
			this.button124.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button124.Name = "button124";
			this.button124.Size = new System.Drawing.Size(53, 49);
			this.button124.TabIndex = 56;
			this.button124.Text = "A8";
			this.button124.UseVisualStyleBackColor = true;
			// 
			// button125
			// 
			this.button125.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button125.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button125.Location = new System.Drawing.Point(65, 403);
			this.button125.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button125.Name = "button125";
			this.button125.Size = new System.Drawing.Size(53, 49);
			this.button125.TabIndex = 57;
			this.button125.Text = "B8";
			this.button125.UseVisualStyleBackColor = true;
			// 
			// button126
			// 
			this.button126.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button126.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button126.Location = new System.Drawing.Point(126, 403);
			this.button126.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button126.Name = "button126";
			this.button126.Size = new System.Drawing.Size(53, 49);
			this.button126.TabIndex = 58;
			this.button126.Text = "C8";
			this.button126.UseVisualStyleBackColor = true;
			// 
			// button127
			// 
			this.button127.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button127.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button127.Location = new System.Drawing.Point(187, 403);
			this.button127.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button127.Name = "button127";
			this.button127.Size = new System.Drawing.Size(53, 49);
			this.button127.TabIndex = 59;
			this.button127.Text = "D8";
			this.button127.UseVisualStyleBackColor = true;
			// 
			// button128
			// 
			this.button128.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button128.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button128.Location = new System.Drawing.Point(248, 403);
			this.button128.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button128.Name = "button128";
			this.button128.Size = new System.Drawing.Size(53, 49);
			this.button128.TabIndex = 60;
			this.button128.Text = "E8";
			this.button128.UseVisualStyleBackColor = true;
			// 
			// button129
			// 
			this.button129.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button129.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button129.Location = new System.Drawing.Point(309, 403);
			this.button129.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button129.Name = "button129";
			this.button129.Size = new System.Drawing.Size(53, 49);
			this.button129.TabIndex = 61;
			this.button129.Text = "F8";
			this.button129.UseVisualStyleBackColor = true;
			// 
			// button130
			// 
			this.button130.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button130.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button130.Location = new System.Drawing.Point(370, 403);
			this.button130.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button130.Name = "button130";
			this.button130.Size = new System.Drawing.Size(53, 49);
			this.button130.TabIndex = 62;
			this.button130.Text = "G8";
			this.button130.UseVisualStyleBackColor = true;
			// 
			// button131
			// 
			this.button131.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button131.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button131.Location = new System.Drawing.Point(431, 403);
			this.button131.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.button131.Name = "button131";
			this.button131.Size = new System.Drawing.Size(53, 49);
			this.button131.TabIndex = 63;
			this.button131.Text = "H8";
			this.button131.UseVisualStyleBackColor = true;
			// 
			// MainScreen
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(1409, 619);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.flowLayoutPanel1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.groupBox2);
			this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.Name = "MainScreen";
			this.Text = "Battleship";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.flowLayoutPanel1.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.Button button14;
		private System.Windows.Forms.Button button15;
		private System.Windows.Forms.Button button16;
		private System.Windows.Forms.Button button17;
		private System.Windows.Forms.Button button18;
		private System.Windows.Forms.Button button19;
		private System.Windows.Forms.Button button20;
		private System.Windows.Forms.Button button21;
		private System.Windows.Forms.Button button22;
		private System.Windows.Forms.Button button23;
		private System.Windows.Forms.Button button24;
		private System.Windows.Forms.Button button25;
		private System.Windows.Forms.Button button26;
		private System.Windows.Forms.Button button27;
		private System.Windows.Forms.Button button28;
		private System.Windows.Forms.Button button29;
		private System.Windows.Forms.Button button30;
		private System.Windows.Forms.Button button31;
		private System.Windows.Forms.Button button32;
		private System.Windows.Forms.Button button33;
		private System.Windows.Forms.Button button34;
		private System.Windows.Forms.Button button35;
		private System.Windows.Forms.Button button36;
		private System.Windows.Forms.Button button37;
		private System.Windows.Forms.Button button38;
		private System.Windows.Forms.Button button39;
		private System.Windows.Forms.Button button40;
		private System.Windows.Forms.Button button41;
		private System.Windows.Forms.Button button42;
		private System.Windows.Forms.Button button43;
		private System.Windows.Forms.Button button44;
		private System.Windows.Forms.Button button45;
		private System.Windows.Forms.Button button46;
		private System.Windows.Forms.Button button47;
		private System.Windows.Forms.Button button48;
		private System.Windows.Forms.Button button49;
		private System.Windows.Forms.Button button50;
		private System.Windows.Forms.Button button51;
		private System.Windows.Forms.Button button52;
		private System.Windows.Forms.Button button53;
		private System.Windows.Forms.Button button54;
		private System.Windows.Forms.Button button55;
		private System.Windows.Forms.Button button56;
		private System.Windows.Forms.Button button57;
		private System.Windows.Forms.Button button58;
		private System.Windows.Forms.Button button59;
		private System.Windows.Forms.Button button60;
		private System.Windows.Forms.Button button61;
		private System.Windows.Forms.Button button62;
		private System.Windows.Forms.Button button63;
		private System.Windows.Forms.Button button64;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button P1S1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button P1S3;
		private System.Windows.Forms.Button P1S2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button button65;
		private System.Windows.Forms.Button button66;
		private System.Windows.Forms.Button button67;
		private System.Windows.Forms.Button button68;
		private System.Windows.Forms.Button button69;
		private System.Windows.Forms.Button button70;
		private System.Windows.Forms.Button button71;
		private System.Windows.Forms.Button button72;
		private System.Windows.Forms.Button button73;
		private System.Windows.Forms.Button button74;
		private System.Windows.Forms.Button button75;
		private System.Windows.Forms.Button button76;
		private System.Windows.Forms.Button button77;
		private System.Windows.Forms.Button button78;
		private System.Windows.Forms.Button button79;
		private System.Windows.Forms.Button button80;
		private System.Windows.Forms.Button button81;
		private System.Windows.Forms.Button button82;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button P2S1;
		private System.Windows.Forms.Button P2S3;
		private System.Windows.Forms.Button P2S2;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private System.Windows.Forms.Button button86;
		private System.Windows.Forms.Button button87;
		private System.Windows.Forms.Button button88;
		private System.Windows.Forms.Button button89;
		private System.Windows.Forms.Button button90;
		private System.Windows.Forms.Button button91;
		private System.Windows.Forms.Button button92;
		private System.Windows.Forms.Button button93;
		private System.Windows.Forms.Button button94;
		private System.Windows.Forms.Button button95;
		private System.Windows.Forms.Button button96;
		private System.Windows.Forms.Button button97;
		private System.Windows.Forms.Button button98;
		private System.Windows.Forms.Button button99;
		private System.Windows.Forms.Button button100;
		private System.Windows.Forms.Button button101;
		private System.Windows.Forms.Button button102;
		private System.Windows.Forms.Button button103;
		private System.Windows.Forms.Button button104;
		private System.Windows.Forms.Button button105;
		private System.Windows.Forms.Button button106;
		private System.Windows.Forms.Button button107;
		private System.Windows.Forms.Button button108;
		private System.Windows.Forms.Button button109;
		private System.Windows.Forms.Button button110;
		private System.Windows.Forms.Button button111;
		private System.Windows.Forms.Button button112;
		private System.Windows.Forms.Button button113;
		private System.Windows.Forms.Button button114;
		private System.Windows.Forms.Button button115;
		private System.Windows.Forms.Button button116;
		private System.Windows.Forms.Button button117;
		private System.Windows.Forms.Button button118;
		private System.Windows.Forms.Button button119;
		private System.Windows.Forms.Button button120;
		private System.Windows.Forms.Button button121;
		private System.Windows.Forms.Button button122;
		private System.Windows.Forms.Button button123;
		private System.Windows.Forms.Button button124;
		private System.Windows.Forms.Button button125;
		private System.Windows.Forms.Button button126;
		private System.Windows.Forms.Button button127;
		private System.Windows.Forms.Button button128;
		private System.Windows.Forms.Button button129;
		private System.Windows.Forms.Button button130;
		private System.Windows.Forms.Button button131;
	}
}

