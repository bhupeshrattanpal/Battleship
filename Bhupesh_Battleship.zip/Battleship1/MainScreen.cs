﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Battleship1
{
	public partial class MainScreen : Form
	{
		List<string> p1ShipPos = new List<string>();
		List<string> p2ShipPos = new List<string>();
		short p1HitCnt = 0;
		short p2HitCnt = 0;
		string playerTurn = "P1";
		public MainScreen()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Attached same functions to all grid buttoons differentiated by players 
		/// </summary>
		private void Form1_Load(object sender, EventArgs e)
		{
			this.label1.Text = "Please choose your ship position (horizonal or vertical in a sequence)";
			foreach (Button btn in flowLayoutPanel1.Controls)
			{
				btn.Click += P1_Button_Click;
			}
			foreach (Button btn in flowLayoutPanel2.Controls)
			{
				btn.Click += P2_Button_Click;
			}
		}

		/// <summary>
		/// Handles clicks for 1st grid
		/// </summary>
		private void P1_Button_Click(object sender, EventArgs e)
		{
			// Set Ship Position
			Control btn = (Button)sender;
			if (p1ShipPos.Count < 3)
			{
				if (!p1ShipPos.Contains(btn.Text))
				{
					if (p1ShipPos.Count == 0)
					{
						p1ShipPos.Add(btn.Text);
						P1S1.Text = btn.Text;
					}
					else if (p1ShipPos.Count == 1 && (Math.Abs(GetButtonPos(p1ShipPos[0]) - GetButtonPos(btn.Text)) == 1 || Math.Abs(GetButtonPos(p1ShipPos[0]) - GetButtonPos(btn.Text)) == 8))
					{
						p1ShipPos.Add(btn.Text);
						P1S2.Text = btn.Text;
					}
					else if (p1ShipPos.Count == 2 && Math.Abs(GetButtonPos(p1ShipPos[1]) - GetButtonPos(btn.Text)) == Math.Abs(GetButtonPos(p1ShipPos[0]) - GetButtonPos(p1ShipPos[1])))
					{
						p1ShipPos.Add(btn.Text);
						P1S3.Text = btn.Text;
					}
				}
			}

			// Main Game Play
			else if (p1ShipPos.Count == 3 && p2ShipPos.Count == 3 && playerTurn == "P1")
			{
				if (p2ShipPos.Contains(btn.Text))
				{
					p1HitCnt++;
					btn.Text = "Hit";
					btn.BackColor = Color.Red;
				}
				else
				{
					btn.Text = "Miss";
				}
				btn.Enabled = false;
				playerTurn = "P2";
				ShowNotification($"Player- {playerTurn.Replace("P", "")} turn");
				if (p1HitCnt >= 3)
				{
					ShowNotification("Player- 1 Won!", true);
					DisableAll();
				}
			}
		}

		/// <summary>
		/// Handles clicks for 2nd grid
		/// </summary>
		private void P2_Button_Click(object sender, EventArgs e)
		{
			// Set Ship Position
			Control btn = (Button)sender;
			if (p2ShipPos.Count < 3)
			{
				if (!p2ShipPos.Contains(btn.Text))
				{
					if (p2ShipPos.Count == 0)
					{
						p2ShipPos.Add(btn.Text);
						P2S1.Text = btn.Text;
					}
					else if (p2ShipPos.Count == 1 && (Math.Abs(GetButtonPos(p2ShipPos[0])-GetButtonPos(btn.Text)) == 1 || Math.Abs(GetButtonPos(p2ShipPos[0]) - GetButtonPos(btn.Text)) == 8))
					{
						p2ShipPos.Add(btn.Text);
						P2S2.Text = btn.Text;
					}
					else if (p2ShipPos.Count == 2 && Math.Abs(GetButtonPos(p2ShipPos[1]) - GetButtonPos(btn.Text)) == Math.Abs(GetButtonPos(p2ShipPos[0]) - GetButtonPos(p2ShipPos[1])))
					{
						p2ShipPos.Add(btn.Text);
						P2S3.Text = btn.Text;
						ShowNotification($"Player- {playerTurn.Replace("P", "")} turn");
					}
				}
			}

			// Main Game Play
			else if (p1ShipPos.Count == 3 && p2ShipPos.Count == 3 && playerTurn == "P2")
			{
				if (p1ShipPos.Contains(btn.Text))
				{
					p2HitCnt++;
					btn.Text = "Hit";
					btn.BackColor = Color.Red;
				}
				else
				{
					btn.Text = "Miss";
				}
				btn.Enabled = false;
				playerTurn = "P1";
				ShowNotification($"Player- {playerTurn.Replace("P","")} turn");
				if (p2HitCnt >= 3)
				{
					ShowNotification("Player- 2 Won!", true);
					DisableAll();
				}
			}
		}


		/// <summary>
		/// This function is called when any player wins
		/// </summary>
		private void DisableAll()
		{
			foreach (Button btn in flowLayoutPanel1.Controls)
			{
				btn.Enabled = false;
			}
			foreach (Button btn in flowLayoutPanel2.Controls)
			{
				btn.Enabled = false;
			}
		}

		/// <summary>
		/// Common function to update notifications
		/// </summary>
		private void ShowNotification(string msg, bool isFinalMsg = false)
		{
			label1.Text = msg;
			if (isFinalMsg)
			{
				Thread t1 = new Thread(() =>
				{
					while (true)
					{
						if (label1.BackColor == Color.Red)
							label1.BackColor = Color.Empty;
						else
							label1.BackColor = Color.Red;
						Thread.Sleep(500);
					}
				});
				t1.Start();
			}
		}

		/// <summary>
		/// Function to convert button text to number sequence
		/// </summary>
		private int GetButtonPos(string btnTxt)
		{
			return (int)btnTxt[0] + ((int.Parse(btnTxt[1].ToString())-1) * 8);
		}
	}
}
